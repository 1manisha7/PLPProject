package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.cg.Exception.QuoteException;
import com.cg.dao.AgentAccountCreationDAO;
import com.cg.dao.AgentPolicyCreationDAO;
import com.cg.dao.IAgentPolicyCreationDAO;

@WebServlet("/GeneratePremiumServlet")
public class GeneratePremiumServlet extends HttpServlet
{
 @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	 int numOfQues=Integer.parseInt(request.getParameter("numberOfQuestions"));
	 
	 List<String> questionId=new ArrayList<>();
	 List<String> answers=new ArrayList<>();
	 List<String> weightage=new ArrayList<>();
	 
	 String quesAans="";
	 int sumOfWeightage=0;
	 int premium=0;
	 for(int i=0;i<numOfQues;i++)
	 {
		 quesAans=request.getParameter((i+1)+"");
		 String qId = quesAans.substring(0,quesAans.indexOf(','));
		 String ans = quesAans.substring(quesAans.indexOf(',')+1,quesAans.lastIndexOf(','));
		 String wghtage = quesAans.substring(quesAans.lastIndexOf(',')+1);
		 
		 questionId.add(qId);
		 answers.add(ans);
		 weightage.add(wghtage);
		 sumOfWeightage=sumOfWeightage+Integer.parseInt(weightage.get(i));
	 }
	 
	 IAgentPolicyCreationDAO iAgentPolicyCreation =  new AgentPolicyCreationDAO();
	 try 
	 {
		premium=iAgentPolicyCreation.getPremiumAmount(sumOfWeightage);
	} 
	 catch (QuoteException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 /*System.out.println(sumOfWeightage);
	 if(sumOfWeightage>=1800 && sumOfWeightage<=2700)
		 premium=100000;
	 else if(sumOfWeightage>2700 && sumOfWeightage<=3600)
		 premium=150000;
	 else if(sumOfWeightage>3600 && sumOfWeightage<=4500)
		 premium=200000;
	 else if(sumOfWeightage>4500 && sumOfWeightage<=5400)
		 premium=250000;
	 */
	 request.setAttribute("PremiumAmount", premium);
	 request.getRequestDispatcher("Premium.jsp").forward(request, response);
	 
	 HttpSession session = request.getSession();
	 long accNo = Long.parseLong(session.getAttribute("accountNumber").toString());
	 String creator=session.getAttribute("usernameA").toString();
	// session.setAttribute("questionId", questionId);
 	 //session.setAttribute("Answers", answers);
	 try 
	 {
		iAgentPolicyCreation.insertPolicy(premium,accNo,questionId,answers,creator);
	 } 
	 catch (QuoteException e) 
	 {
		// TODO Auto-generated catch block
		e.printStackTrace();
	 }
	 
}
}
