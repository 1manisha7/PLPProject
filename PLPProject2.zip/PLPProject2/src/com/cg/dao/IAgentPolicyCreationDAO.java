package com.cg.dao;

import java.sql.ResultSet;
import java.util.List;

import com.cg.Exception.QuoteException;
import com.cg.model.PolicyQuestions;

public interface IAgentPolicyCreationDAO
{
 public String isAccountExists(int accNumber) throws QuoteException;
 public List<PolicyQuestions> findQuestions(String bus_seg_id) throws QuoteException;
 public Integer getPremiumAmount(int sumofWeightage) throws QuoteException;
 public void insertPolicy(int premium,long accountNo,List<String> questionId,List<String> answers,String creator) throws QuoteException;
 
 public ResultSet viewPolicy(String username) throws QuoteException;
}
