package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;
import com.cg.model.UserRole;
import com.cg.utility.DbConnection;

public class UserRoleDAO implements IUserRoleDAO 
{
	
	static Connection connection=null;
	static PreparedStatement statement=null;
	static ResultSet resultset=null;
	
	@Override
	public String verifyUser(UserRole userRole) throws QuoteException 
	{
		String roleCode="";
		try
		{
		connection = DbConnection.getConnection();
		statement = connection.prepareStatement(QueryConstants.VERIFY_USER);
		statement.setString(1, userRole.getUserName());
		statement.setString(2, userRole.getPassword());
		resultset = statement.executeQuery();
		if(resultset.next())
			roleCode = resultset.getString(3);
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try
			{
				statement.close();
				connection.close();
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return roleCode;
		
	}

	//@Override
	public int addUser(UserRole userRole) throws QuoteException {
		int rowInserted=0;
		
		//String insertQuery="insert into userRole values(?,?,?)";
		try
		{
			connection = DbConnection.getConnection();
	      //System.out.println("conn");
			statement=connection.prepareStatement(QueryConstants.INSERT_USER);
			statement.setString(1, userRole.getUserName());
			statement.setString(2, userRole.getPassword());
			statement.setString(3, userRole.getRoleCode());
			rowInserted=statement.executeUpdate();
			//System.out.println(id);
		}
		catch(SQLException e)
		{
			System.out.println("db error!!");
		}
		finally {
			try
			{
				connection.close();
			}
			catch (Exception e) {
				System.out.println("userName already exist");
			}
		}
		return rowInserted;
	}
	
		
	

	@Override
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QuoteException {
		String businessSegmentId = null;
		boolean found = false;
		System.out.println("name:"+lineOfBusinessName);
		try {
			connection = DbConnection.getConnection();

			statement = connection.prepareStatement(QueryConstants.GET_LOB_NAME);
			statement.setString(1, lineOfBusinessName);
			
			resultset = statement.executeQuery();
			//System.out.println("printing resultset:"+resultset.getString(1));
			found = resultset.next();
			//System.out.println("Inside dao:"+found);
			if(found == true) {
				businessSegmentId = resultset.getString(1);
				//System.out.println(name + " " + pwd);
			}
			System.out.println("Inside dao:"+businessSegmentId);
		} catch (SQLException e) {
			throw new QuoteException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QuoteException("problem while closing");
			}

		}
		return businessSegmentId;
	}
	
	@Override
	public boolean isUserExists(String userName) throws QuoteException {
		boolean found = false;
		try {
			connection = DbConnection.getConnection();

			statement = connection.prepareStatement(QueryConstants.USER_EXISTS);
			statement.setString(1, userName);
			resultset = statement.executeQuery();
			if(resultset.next()) {
				found = true;
			}
		} catch (SQLException e) {
			throw new QuoteException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QuoteException("problem while closing");
			}

		}
        return found;
	}
	/*public static void main(String[] args) throws QuoteException {
		UserRole ur = new UserRole("manisha", "123", "UW");
		System.out.println(UserRoleDAO.addUser(ur));
	}*/

	@Override
	public boolean isUserExistsInAccounts(String userName) throws QuoteException {
		boolean isUserExists = false;
		try {
			connection = DbConnection.getConnection();

			statement = connection.prepareStatement(QueryConstants.USER_EXISTS_IN_ACCOUNT);
			statement.setString(1, userName);
			resultset = statement.executeQuery();
			if(resultset.next()) {
				isUserExists = true;
			}
		} catch (SQLException e) {
			throw new QuoteException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QuoteException("problem while closing");
			}

		}
        return isUserExists;
	}
}
