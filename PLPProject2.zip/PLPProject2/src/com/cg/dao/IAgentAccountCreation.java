package com.cg.dao;

import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;

public interface IAgentAccountCreation 
{
public String isUserExist(String usernname) throws QuoteException;

public String isAccountExists(String userName) throws QuoteException;

public int createAccount(Accounts account) throws QuoteException;
}
