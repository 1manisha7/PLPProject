package com.cg.dao;

import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;

public interface IAccountsDAO {

	int accountCreation(Accounts account, String userName) throws QuoteException;
}
