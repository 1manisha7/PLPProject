package com.cg.dao;

import com.cg.Exception.QuoteException;
import com.cg.model.Accounts;
import com.cg.model.UserRole;

public interface IUserRoleDAO 
{
	public String verifyUser(UserRole userRole) throws QuoteException;
	
	public int addUser(UserRole userRole) throws QuoteException;

	public boolean isUserExists(String userName) throws QuoteException;
	
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QuoteException;
	
	public boolean isUserExistsInAccounts(String userName) throws QuoteException;
}

