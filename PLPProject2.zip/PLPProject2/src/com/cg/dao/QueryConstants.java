package com.cg.dao;

public interface QueryConstants {

	String VERIFY_USER = "SELECT * FROM USERROLE WHERE username=? and password=?";
	
	String INSERT_USER = "insert into userRole values(?,?,?)";

	String GET_ROLECODE = "select rolecode from userrole where username = ? and password = ?";
	
	String ACCOUNT_CREATION = "insert into accounts values(?,?,?,?,?,?,?,?)";
	
	String GET_LOB_NAME = "select bus_seg_id from businesssegment where bus_seg_name = ?";
	
	String USER_EXISTS = "select * from userrole where username = ?";
	
	String USER_EXISTS_IN_ACCOUNT = "select username from accounts where username = ?";
	
	
	//Agent.....
	 String AGENT_VERIFY_USER="SELECT ROLECODE FROM USERROLE WHERE USERNAME=?";
	 
	 String AGENT_VERIFY_ACCOUNT="SELECT BUSINESSSEGMENTID FROM ACCOUNTS WHERE ACCOUNTNUMBER=?";
	 
	 String AGENT_POLICY_QUESTIONS="SELECT * FROM POLICYQUESTIONS WHERE BUS_SEG_ID=?";
	 
	 String GET_POLICY_PREMIUM="SELECT PRE_AMT FROM PREMIUMS WHERE ? BETWEEN PRE_ANS_WEIGHTAGE_MIN AND PRE_ANS_WEIGHTAGE_MAX";
	 
	 String INSERT_POLICY="INSERT INTO POLICY VALUES(policyNumberSeq.nextval,?,?)";
	 
	 String INSERT_POLICYDETAILS="INSERT INTO POLICYDETAILS VALUES((SELECT MAX(POLICYNUMBER) FROM POLICY),?,?)";
	 
	 String INSERT_POLICYCREATOR="INSERT INTO POLICYCREATOR VALUES((SELECT MAX(POLICYNUMBER) FROM POLICY),?)";
	 
	 //VIEW POLICY
	 
	 String VIEW_POLICY="SELECT  * FROM POLICY WHERE POLICYNUMBER IN (SELECT POLICYNUMBER FROM POLICYCREATOR WHERE CREATOR=?)";
	 
	 
	
}
