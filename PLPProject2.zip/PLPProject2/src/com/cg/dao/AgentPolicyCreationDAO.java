package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.Exception.QuoteException;
import com.cg.model.PolicyQuestions;
import com.cg.utility.DbConnection;

public class AgentPolicyCreationDAO implements IAgentPolicyCreationDAO
{
Connection connection=null;
PreparedStatement statement=null;
ResultSet resultset=null;
ResultSet resultset1=null;
PreparedStatement statement1=null;
@Override
public String isAccountExists(int accNumber) throws QuoteException
{
	String bus_seg_id="";
	try 
	{
		connection=DbConnection.getConnection();
		statement=connection.prepareStatement(QueryConstants.AGENT_VERIFY_ACCOUNT);
		statement.setInt(1, accNumber);
		resultset=statement.executeQuery();
		while(resultset.next())
		{
		 bus_seg_id=resultset.getString(1);
		}
	} 
	catch (QuoteException | SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return bus_seg_id;
}
@Override
public List<PolicyQuestions> findQuestions(String bus_seg_id) throws QuoteException
{
	List<PolicyQuestions> quesList=new ArrayList<>();
   
	try
	{
		connection = DbConnection.getConnection();
		statement = connection.prepareStatement(QueryConstants.AGENT_POLICY_QUESTIONS);
		statement.setString(1, bus_seg_id);
		resultset=statement.executeQuery();
		while(resultset.next())
		{
			PolicyQuestions polQues=new PolicyQuestions();
			polQues.setPolQuesId(resultset.getString(1));
			polQues.setPolQuesSeq(resultset.getInt(2));
			polQues.setBusSegId(resultset.getString(3));
			polQues.setPolQuesDesc(resultset.getString(4));
			polQues.setPolQuesAns1(resultset.getString(5));
			polQues.setPolQuesAns1Weightage(resultset.getInt(6));
			polQues.setPolQuesAns2(resultset.getString(7));
			polQues.setPolQuesAns2Weightage(resultset.getInt(8));
			polQues.setPolQuesAns3(resultset.getString(9));
			polQues.setPolQuesAns3Weightage(resultset.getInt(10));
			
			quesList.add(polQues);
		}
	} 
	catch (SQLException | QuoteException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
 return quesList;
}
@Override
public Integer getPremiumAmount(int sumofWeightage) throws QuoteException
{
	int premiumAmt=0;
	boolean found = false;
	System.out.println("sum of weightage in dao:"+sumofWeightage);
	try {
		connection = DbConnection.getConnection();
		statement = connection.prepareStatement(QueryConstants.GET_POLICY_PREMIUM);
		statement.setInt(1, sumofWeightage);
		resultset=statement.executeQuery();
		
		while(resultset.next()) 
		{
			premiumAmt=resultset.getInt(1);
			System.out.println("premium amt in dao:"+premiumAmt);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	return premiumAmt;
}
@Override
public void insertPolicy(int premium,long accountNo, List<String> questions, List<String> answers, String creator) throws QuoteException
{
	int rowsInserted=0;
	try 
	{
		connection=DbConnection.getConnection();
		statement1=connection.prepareStatement(QueryConstants.INSERT_POLICY);
		//statement1.setInt(1,policyNumberSeq);
		statement1.setInt(1,premium);
		statement1.setLong(2, accountNo);
		rowsInserted=statement1.executeUpdate();
		statement1=connection.prepareStatement(QueryConstants.INSERT_POLICYDETAILS);
		for(int i=0;i<questions.size();i++)
		{
			statement1.setString(1, questions.get(i));
			statement1.setString(2, answers.get(i));
			statement1.executeUpdate();
		}
		statement1=connection.prepareStatement(QueryConstants.INSERT_POLICYCREATOR);
		statement1.setString(1, creator);
		statement1.executeUpdate();
	} 
	catch (QuoteException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			statement1.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
@Override
public ResultSet viewPolicy(String username) throws QuoteException
{
	try {
		connection=DbConnection.getConnection();
		statement=connection.prepareStatement(QueryConstants.VIEW_POLICY);
		statement.setString(1, username);
		resultset=statement.executeQuery();
	} catch (QuoteException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return resultset;
}
}
