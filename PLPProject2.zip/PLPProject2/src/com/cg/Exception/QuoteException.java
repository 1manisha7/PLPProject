package com.cg.Exception;

public class QuoteException extends Exception
{
 public QuoteException(String message)
 {
	 super(message);
 }
}
