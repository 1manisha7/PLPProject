package com.cg.qgs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.dao.IAdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Policy;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;

@WebServlet("/ViewPolicy")
public class ViewPolicy extends HttpServlet{
	
	final Logger logger = Logger.getLogger(AgentViewPolicy.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Creating an object to Agent Service class
		IAdminService service = new AdminService();
		RequestDispatcher dispatcher = null;
		try {
			
			//Getting the list of all policies
			List<Policy> policies = service.getPolicies();
			System.out.println(policies);
			request.setAttribute("policies", policies);
			logger.info("Getting and displaying  the list of all policies");
			dispatcher = request.getRequestDispatcher("viewpolicy.jsp");
			dispatcher.include(request, response);
		}catch (QGSException e) {
			response.sendRedirect("adminExceptionPage.jsp");
			logger.info("Error while creating an account by admin");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("adminExceptionPage.jsp");
			e.printStackTrace();
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
}
