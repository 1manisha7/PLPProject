package com.cg.qgs.controller;
import org.apache.log4j.Logger;
public class myLogger {
	static Logger myLogger =  Logger.getLogger(myLogger.class.getName());
	Object x;
	
}

