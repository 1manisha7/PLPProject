package com.cg.qgs.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.List;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Policy;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.AgentService;
import com.cg.qgs.service.IAdminService;
import com.cg.qgs.service.IAgentService;

@WebServlet("/AgentViewPolicy")
public class AgentViewPolicy extends HttpServlet{
	
	final Logger logger = Logger.getLogger(AgentViewPolicy.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAgentService service = new AgentService();
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		try {
			
			//Getting the policies displayed by agent
			String username = (String)session.getAttribute("username");
			List<Policy> policies = service.getPolicies(username);
			request.setAttribute("policies", policies);
			logger.info("Getting and displaying  the list of policies created by agent");
			dispatcher = request.getRequestDispatcher("agentviewpolicy.jsp");
			dispatcher.include(request, response);
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

}
