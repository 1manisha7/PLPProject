package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;
import com.cg.qgs.service.IInsuredService;
import com.cg.qgs.service.InsuredService;

@WebServlet("/InsuredAccountCreation")
public class InsuredAccountCreation extends HttpServlet {
	
	final Logger logger = Logger.getLogger(InsuredAccountCreation.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//Creating an object to Insured Service class
		IInsuredService service = new InsuredService();
		
		int isCreated = 0;
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		boolean isUserExists = false;
		try {
			//Getting details using request object from the form
			String userName = request.getParameter("userName");
			String insuredName = request.getParameter("insuredName");
			String insuredStreet = request.getParameter("insuredStreet");
			String insuredCity = request.getParameter("insuredCity");
			String insuredState = request.getParameter("insuredState");
			int insuredZip = Integer.parseInt(request.getParameter("insuredZip"));
			String busSegName = request.getParameter("busSegName");
			logger.info("Getting Account details from user for creating a new account");
			
			
			
			String bussinessSegmentId = service.getLineOfBusinessIdByName(busSegName);
			
			//sending the values to the bean class using constructor
			Accounts account = new Accounts(insuredName, insuredStreet, insuredCity, insuredState, insuredZip, bussinessSegmentId);
			
			isCreated = service.accountCreation(account, userName);
			if (isCreated == 1) {
				logger.info("Account Created Successfully!!");
				out.println("Account Created Successfully!!");
				dispatcher = request.getRequestDispatcher("insurerhome.html");
				dispatcher.forward(request, response);
			}
			
		} catch (QGSException e) {
			response.sendRedirect("insuredExceptionPage.jsp");
			logger.info("Error while creating an account");
			System.out.println(e.getMessage());
		} catch (Exception e) {
			response.sendRedirect("insuredExceptionPage.jsp");
			logger.info("Error while creating an account");
			System.out.println(e.getMessage());
		}

	}
}
