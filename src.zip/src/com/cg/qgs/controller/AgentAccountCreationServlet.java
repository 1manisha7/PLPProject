package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.service.AgentService;
import com.cg.qgs.service.IAgentService;


@WebServlet("/AgentAccountCreationServlet")
public class AgentAccountCreationServlet extends HttpServlet {
	
	final Logger logger = Logger.getLogger(AgentAccountCreationServlet.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Creating an object to Agent Service class
        IAgentService service = new AgentService();
		
        int isCreated = 0;
        boolean isAccountExists = false;
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		boolean isUserExists = false;
		try {
			//Getting details using request object from the form
			String userName = request.getParameter("userName");
			String insuredName = request.getParameter("insuredName");
			String insuredStreet = request.getParameter("insuredStreet");
			String insuredCity = request.getParameter("insuredCity");
			String insuredState = request.getParameter("insuredState");
			int insuredZip = Integer.parseInt(request.getParameter("insuredZip"));
			String busSegName = request.getParameter("busSegName");
			logger.info("Getting Account details from user for creating a new account");
			
		
				
			//If user already exists then account is created for the user
			String bussinessSegmentId = service.getLineOfBusinessIdByName(busSegName);
			
			//sending the values to the bean class using constructor
			Accounts account = new Accounts(insuredName, insuredStreet, insuredCity, insuredState, insuredZip, bussinessSegmentId);
			
			isUserExists = service.isUserExists(userName);
			if (isUserExists) {
                
				isAccountExists = service.accountValidation(userName);
				if(isAccountExists) {
					out.println("Account already exists");
					logger.info("Account already exists");
					
					dispatcher = request.getRequestDispatcher("agenthome.jsp");
					dispatcher.include(request, response);
				} else {
				    isCreated = service.accountCreation(account, userName);
				    if (isCreated == 1) {
					out.println("Account Created Successfully!!");
					logger.info("Account created successfully");
					
					dispatcher = request.getRequestDispatcher("agenthome.jsp");
					dispatcher.include(request, response);
				   }
				}
			} else {
				out.println("User does not exists! First register as user");
				logger.info("User does not exists! First register as user");
				
				dispatcher = request.getRequestDispatcher("agenthome.jsp");
				dispatcher.include(request, response);
			}
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}

	}

}
