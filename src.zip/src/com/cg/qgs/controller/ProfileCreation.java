package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.dao.IAdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.UserRole;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;

@WebServlet("/ProfileCreation")
public class ProfileCreation extends HttpServlet {
	
	final Logger logger = Logger.getLogger(ProfileCreation.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		int isInserted = 0;
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		
		//Creating an object to Admin Service class
		IAdminService service = new AdminService();
		
		
		try {
			//Getting username,password and rolecode using request object from the form
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String rolecode = request.getParameter("rolecode");
			
	        //sending the values to the bean class using constructor
			UserRole userRole = new UserRole(username, password, rolecode);
			//profile is created for the user if the user does'nt exists  
			isInserted = service.addUser(userRole);
			if (isInserted > 0) {
				logger.info("User Role created successfully!!!!");
				dispatcher = request.getRequestDispatcher("adminhome.html");
				dispatcher.include(request, response);
			} else {
				logger.info("Username already exists!! Enter a different Username");
				dispatcher = request.getRequestDispatcher("profilecreation.html");
				dispatcher.include(request, response);
			}
		}catch (QGSException e) {
			response.sendRedirect("adminExceptionPage.jsp");
			logger.info("Error while creating an account by admin");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("adminExceptionPage.jsp");
			e.printStackTrace();
		}
	}
}
