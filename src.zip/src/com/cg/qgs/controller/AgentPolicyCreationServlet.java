package com.cg.qgs.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.service.AgentService;
import com.cg.qgs.service.IAgentService;

@WebServlet("/AgentPolicyCreationServlet")
public class AgentPolicyCreationServlet extends HttpServlet {

	final Logger logger = Logger.getLogger(AgentAccountCreationServlet.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Creating the servlet context object
		ServletContext context = request.getServletContext();
		try {
			
		int accNumber = Integer.parseInt(request.getParameter("accNo"));
		
		//setting account number to the context object
		context.setAttribute("accNumber", accNumber);
		PrintWriter out = response.getWriter();
	    
		//Creating an object to Agent Service class
		IAgentService service = new AgentService();
		
		List<PolicyQuestions> policyQuestions = new ArrayList<PolicyQuestions>();
		RequestDispatcher dispatcher = null;
		
		
		boolean isAccountExists = false;
		
		
			
			//displaying policy questions for the particular business segment
			isAccountExists = service.isAccountExists(accNumber);
			if(isAccountExists) {
				String busSegId = service.getBusSegId(accNumber);
				context.setAttribute("busSegId", busSegId);
				policyQuestions = service.getPolicyQuestions(busSegId);
				logger.info("Getting policy questions based on business segment id");
				dispatcher = request.getRequestDispatcher("agentpolicyquestions.jsp");
				
				request.setAttribute("questions", policyQuestions);
				dispatcher.forward(request, response);
			} else {
				
				out.println("Account does not exists, so create an account");
				logger.info("Account does not exists, so create an account");
				dispatcher = request.getRequestDispatcher("agenthome.jsp");
				dispatcher.include(request, response);

			}
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
		
	}
}
