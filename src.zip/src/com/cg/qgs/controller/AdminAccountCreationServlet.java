package com.cg.qgs.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.logging.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;

@WebServlet("/AccountCreationServlet")
public class AdminAccountCreationServlet extends HttpServlet{
	
	final Logger logger = Logger.getLogger(AdminAccountCreationServlet.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		// TODO Auto-generated method stub
		
		//Creating an object to Admin Service class
		IAdminService service = new AdminService();
		int isCreated = 0;
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		boolean isUserExists = false;
		try {
		//Getting details using request object from the form
		String userName = request.getParameter("userName");
		String insuredName = request.getParameter("insuredName");
		String insuredStreet = request.getParameter("insuredStreet");
		String insuredCity = request.getParameter("insuredCity");
		String insuredState = request.getParameter("insuredState");
		int insuredZip = Integer.parseInt(request.getParameter("insuredZip"));
		String busSegName = request.getParameter("busSegName");
		logger.info("Getting Account details from user for creating a new account");
		
			
			//If user already exists then account is created for the user
			String bussinessSegmentId = service.getLineOfBusinessIdByName(busSegName);
			
			//sending the values to the bean class using constructor
			Accounts account = new Accounts(insuredName, insuredStreet, insuredCity, insuredState, insuredZip, bussinessSegmentId);
            
			
			isUserExists = service.isUserExists(userName);
			if (isUserExists) {

				isCreated = service.accountCreation(account, userName);
				if (isCreated == 1) {
					out.println("Account Created Successfully");
					logger.info("Account is created successfully");
					dispatcher = request.getRequestDispatcher("adminhome.html");
					dispatcher.include(request, response);
				}
			} else {
				out.println("User does not exists! First register as user");
				logger.info("User does not exists! First register as user");
				dispatcher = request.getRequestDispatcher("adminhome.html");
				dispatcher.include(request, response);
			}
		}catch (QGSException e) {
			response.sendRedirect("adminExceptionPage.jsp");
			logger.info("Error while creating an account by admin");
		}
		catch (Exception e) {
			response.sendRedirect("adminExceptionPage.jsp");
			logger.info("Error while creating an account by admin");
		}

	}
	
}
