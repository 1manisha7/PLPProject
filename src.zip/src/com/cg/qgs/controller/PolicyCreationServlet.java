package com.cg.qgs.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.qgs.dao.AdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.service.AdminService;
import com.cg.qgs.service.IAdminService;
@WebServlet("/PolicyCreationServlet")
public class PolicyCreationServlet extends HttpServlet {

	final Logger logger = Logger.getLogger(PolicyCreationServlet.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		RequestDispatcher dispatcher = null;
		
		//Creating the servlet context object
		ServletContext context = request.getServletContext();
		
		
		PrintWriter out = response.getWriter();
	    
		//Creating an object to Admin Service class
		IAdminService service = new AdminService();
		try {
			
			int accNumber = Integer.parseInt(request.getParameter("accNumber"));
			//setting account number to the context object
			context.setAttribute("accNumber", accNumber);
			List<PolicyQuestions> policyQuestions = new ArrayList<PolicyQuestions>();
		
			
			//displaying policy questions for the particular business segment
			String busSegId = service.getBusSegId(accNumber);
			
			//Setting the value of attribute using context object
			context.setAttribute("busSegId", busSegId);
			policyQuestions = service.getPolicyQuestions(busSegId);
			logger.info("Getting policy questions based on business segment id");
			dispatcher = request.getRequestDispatcher("policycreationquestions.jsp");
			request.setAttribute("questions", policyQuestions);
			dispatcher.forward(request, response);
		}catch (QGSException e) {
			response.sendRedirect("adminExceptionPage.jsp");
			logger.info("Error while creating an account by admin");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("adminExceptionPage.jsp");
			e.printStackTrace();
		}
		
	}
}
