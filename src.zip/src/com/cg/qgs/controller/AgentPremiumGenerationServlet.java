package com.cg.qgs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Policy;
import com.cg.qgs.service.AgentService;
import com.cg.qgs.service.IAgentService;

@WebServlet("/AgentPremiumGenerationServlet")
public class AgentPremiumGenerationServlet extends HttpServlet
{
 @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	 
	 final Logger logger = Logger.getLogger(AgentAccountCreationServlet.class);
	 PrintWriter out = response.getWriter();

		ServletContext context = request.getServletContext();
		int polPremium = 0;
		int sumOfWeightages = 0;
		int isInserted = 0;
		int accNumber = 0;
		int polNumber = 0;
		
		try { 
			
			int numOfQuestions = Integer.parseInt(request.getParameter("numofquestions"));
			HttpSession session = request.getSession();
			List<String> questionIds = new ArrayList<String>();
			List<String> selectedAnswers = new ArrayList<String>();
			RequestDispatcher dispatcher = null;
			List<Integer> weightages = new ArrayList<Integer>();
			logger.info("Getting the selected answers");
			String[] qAndA = null;
			for(int i = 0; i < numOfQuestions; i++) {
				qAndA = new String[3];
				qAndA = ((String)request.getParameter(""+(i+1))).split("!");
				questionIds.add(qAndA[0]);
				selectedAnswers.add(qAndA[1]);
				weightages.add(Integer.parseInt(qAndA[2]));
				//calculating sum of weightages for the selected answers
				sumOfWeightages += weightages.get(i);
			}
			
			//Creating an object to Agent Service class
			IAgentService service = new AgentService();
			Policy policy = new Policy();
			
			
			//Creating policy for the user
			accNumber = Integer.parseInt(""+context.getAttribute("accNumber"));
			polPremium = service.getPolicyPremiumAmount(sumOfWeightages);
			policy.setAccNumber(accNumber);
			policy.setPolicyPremium(polPremium);
			isInserted = service.createPolicy(policy);
			if(isInserted > 0) {
				out.println("Policy created successfully!!!!");
				logger.info("Policy created successfully");
				polNumber = service.getPolicyNumber();
				String username = (String)session.getAttribute("username");
				service.addPolicyDetails(polNumber, questionIds, selectedAnswers);
				service.addPolicyCreator(polNumber,username);
				dispatcher = request.getRequestDispatcher("agenthome.jsp");
				dispatcher.include(request, response);
				
			}		
		} catch (QGSException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("agentExceptionPage.jsp");
			logger.info("Error while getting the list of policies created by agent");
			e.printStackTrace();
		}

}
}
