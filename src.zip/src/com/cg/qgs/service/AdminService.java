package com.cg.qgs.service;

import java.util.List;

import com.cg.qgs.dao.AdminDAO;

import com.cg.qgs.dao.IAdminDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.model.UserRole;

public class AdminService implements IAdminService {

	IAdminDAO adminDao = new AdminDAO();
	@Override
	public boolean loginValidation(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.loginValidation(username, password);
	}

	@Override
	public String getRoleCode(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getRoleCode(username, password);
	}

	@Override
	public int addUser(UserRole userRole) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.addUser(userRole);
	}
	
	@Override
	public int accountCreation(Accounts account, String userName) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.accountCreation(account,userName);
	}

	@Override
	public String getLineOfBusinessIdByName(String busSegName) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getLineOfBusinessIdByName(busSegName);
	}

	@Override
	public boolean isUserExists(String userName) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.isUserExists(userName);
	}

	@Override
	public String getBusSegId(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getBusSegId(accNumber);
	}

	@Override
	public List<PolicyQuestions> getPolicyQuestions(String busSegId) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getPolicyQuestions(busSegId);
	}

	@Override
	public int getPolicyPremiumAmount(int sumOfWeightages) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getPolicyPremiumAmount(sumOfWeightages);
	}

	@Override
	public int createPolicy(Policy policy) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.createPolicy(policy);
	}

	@Override
	public int getPolicyNumber() throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getPolicyNumber();
	}

	@Override
	public void addPolicyDetails(int polNumber, List<String> questionIds, List<String> selectedAnswers)
			throws QGSException {
		// TODO Auto-generated method stub
		adminDao.addPolicyDetails(polNumber, questionIds, selectedAnswers);
	}

	@Override
	public List<Policy> getPolicies() throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getPolicies();
	}

	@Override
	public Accounts getAccountDetails(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getAccountDetails(accNumber);
	}

	@Override
	public String getBusSegName(String lineOfBusiness) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getBusSegName(lineOfBusiness);
	}

	@Override
	public Double getPolicyPremium(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getPolicyPremium(polNum);
	}

	@Override
	public List<String> getSelectedAnswers(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		return adminDao.getSelectedAnswers(polNum);
	}
	

}
