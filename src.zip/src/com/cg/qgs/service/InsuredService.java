package com.cg.qgs.service;

import java.util.List;

import com.cg.qgs.dao.IInsuredDAO;
import com.cg.qgs.dao.InsuredDAO;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyQuestions;

public class InsuredService implements IInsuredService{

	IInsuredDAO insuredDao = new InsuredDAO();
	@Override
	public String getLineOfBusinessIdByName(String busSegName) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getLineOfBusinessIdByName(busSegName);
	}

	@Override
	public int accountCreation(Accounts account, String userName) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.accountCreation(account, userName);
	}


	@Override
	public boolean accountValidation(String username) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.accountValidation(username);
	}


	@Override
	public int getAccountNumber(String username) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getAccountNumber(username);
	}


	@Override
	public List<Policy> getInsuredPolicies(int accNo) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getInsuredPolicies(accNo);
	}


	@Override
	public Accounts getAccountDetails(int accNo) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getAccountDetails(accNo);
	}


	@Override
	public String getBusSegName(String lineOfBusiness) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getBusSegName(lineOfBusiness);
	}


	@Override
	public Double getPolicyPremium(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getPolicyPremium(polNum);
	}


	@Override
	public List<PolicyQuestions> getPolicyQuestions(String lineOfBusiness) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getPolicyQuestions(lineOfBusiness);
	}


	@Override
	public List<String> getSelectedAnswers(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		return insuredDao.getSelectedAnswers(polNum);
	}


	

}
