package com.cg.qgs.dao;

public interface AgentQueryConstants {

	 //Account Creation
	
	 String GET_LOB_NAME = "SELECT bus_seg_id FROM businesssegment WHERE bus_seg_name = ?";
	 
	 String USER_EXISTS = "SELECT * FROM userrole WHERE username = ?";
	 
	 String ACCOUNT_CREATION = "INSERT INTO accounts VALUES(?,?,?,?,?,?,?,?)";
	 
	 String VALIDATE_ACCOUNT_QUERY ="SELECT * FROM accounts WHERE username = ?";
	 
	 //Policy creation 
	 
	 String VALIDATE_ACCOUNT = "SELECT * FROM accounts WHERE accountnumber = ?";
	 
	 String GET_BUS_SEG_ID = "SELECT businesssegmentid FROM accounts WHERE accountnumber = ?";
	 
	 String GET_POLICY_QUESTIONS = "SELECT * FROM policyquestions WHERE bus_seg_id = ?";
	 
	 String GET_POLICY_PREMIUM_AMOUNT = "SELECT pre_amt FROM premiums WHERE ? BETWEEN pre_ans_weightage_min AND pre_ans_weightage_max";
	 
	 String CREATE_POLICY = "INSERT INTO policy VALUES(policy_number.nextval, ?, ?)";
	 
	 String GET_POLICY_NUMBER = "SELECT MAX(policynumber) FROM policy";
	 
	 String ADD_POLICY_DETAILS = "INSERT INTO policydetails VALUES(?,?,?)";
	 
	 String ADD_POLICY_CREATOR = "INSERT INTO policycreator VALUES(?,?)";
	 
	 //View Policy
	 
	 String VIEW_POLICY="SELECT  * FROM policy WHERE policynumber IN (SELECT policynumber FROM policycreator WHERE username=?)";
	 
	 //Generating Report
	 
	 String GET_ACCOUNT_DETAILS = "SELECT * FROM accounts WHERE accountnumber = ?";
	 
	 String GET_BUS_SEG_NAME = "SELECT bus_seg_name FROM businesssegment WHERE bus_seg_id = ?";
	 
	 String GET_POLICY_PREMIUM = "SELECT policypremium FROM policy WHERE policynumber = ?";
	 
	 String GET_SELECTED_ANSWERS = "SELECT answer FROM policydetails WHERE policynumber = ?";
	


}
