package com.cg.qgs.dao;

public interface InsuredQueryConstants {

	//Account validation
	
	String VALIDATE_ACCOUNT_QUERY ="SELECT * FROM accounts WHERE username = ?";

	//Account Creation
	
	String GET_LOB_NAME = "SELECT bus_seg_id FROM businesssegment WHERE bus_seg_name = ?";
	
	String ACCOUNT_CREATION = "INSERT INTO accounts VALUES(account_number.nextval,?,?,?,?,?,?,?)";
	
	//view policy
	
	String GET_ACCOUNT_NUMBER = "SELECT accountnumber FROM accounts WHERE username = ? ";
	
	String GET_INSURED_POLICY = "select * from policy where accountnumber = ? ";
	
	//Generate Report
	
	String GET_BUS_SEG_NAME = "SELECT bus_seg_name FROM businesssegment WHERE bus_seg_id = ?";
	
	String GET_ACCOUNT_DETAILS = "SELECT * FROM accounts WHERE accountnumber = ?";
	
	String GET_POLICY_PREMIUM = "SELECT policypremium FROM policy WHERE policynumber = ?";
	
	String GET_POLICY_QUESTIONS = "SELECT * FROM policyquestions WHERE bus_seg_id = ?";
	
	String GET_SELECTED_ANSWERS = "SELECT answer FROM policydetails WHERE policynumber = ?";
	
}
