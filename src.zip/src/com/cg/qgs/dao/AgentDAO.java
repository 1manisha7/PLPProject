package com.cg.qgs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.qgs.controller.ProfileCreation;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyDetails;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.utility.JdbcUtility;

public class AgentDAO implements IAgentDAO {
	
	final Logger logger = Logger.getLogger(ProfileCreation.class);
	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;

	//Method for getting business Segment Id from business segment name
	@Override
	public String getLineOfBusinessIdByName(String busSegName) throws QGSException {
		// TODO Auto-generated method stub
		String businessSegmentId = null;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_LOB_NAME);
			prepareStatement.setString(1, busSegName);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				businessSegmentId = resultSet.getString(1);
				logger.info("Business segment id based on business segment name is: "+businessSegmentId);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return businessSegmentId;
	}
	
	//Method to Check whether the user exists or not
	@Override
	public boolean isUserExists(String userName) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.USER_EXISTS);
			prepareStatement.setString(1, userName);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
				logger.info("User exists so account can be created for the user with username: "+userName);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}
	
	@Override
	public boolean accountValidation(String userName) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.VALIDATE_ACCOUNT_QUERY);
			prepareStatement.setString(1, userName);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;

	}
	
	//Method for creating a new account
	@Override
	public int accountCreation(Accounts account, String userName) throws QGSException {
		// TODO Auto-generated method stub
		connection = JdbcUtility.getConnection();
		int isInserted = 0;
		try {
			prepareStatement = connection.prepareStatement(AdminQueryConstants.ACCOUNT_CREATION);
			prepareStatement.setString(1, account.getInsuredName());
			prepareStatement.setString(2, account.getInsuredStreet());
			prepareStatement.setString(3, account.getInsuredCity());
			prepareStatement.setString(4, account.getInsuredState());
			prepareStatement.setInt(5, account.getInsuredZip());
			prepareStatement.setString(6, account.getLineOfBusiness());
			prepareStatement.setString(7, userName);
			
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting account details of the user into the accounts table with username: "+userName);

		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				prepareStatement.close();
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return isInserted;

	}

	//Method to check whether the user exists to create a new account
	@Override
	public boolean isAccountExists(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.VALIDATE_ACCOUNT);
			prepareStatement.setInt(1, accNumber);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;

	}
	
	//Method for getting business segment id of the user to create a policy
	@Override
	public String getBusSegId(int accNumber) throws QGSException {
		String busSegId = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_BUS_SEG_ID);
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegId = resultSet.getString(1);
				logger.info("Getting the business segment id from accounts table for account number "+accNumber +" " +" for creating a new policy");
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return busSegId;
		
	}
	
	//Method for getting policy questions for the related business segment
	@Override
	public List<PolicyQuestions> getPolicyQuestions(String busSegId) throws QGSException {
		// TODO Auto-generated method stub
		
		List<PolicyQuestions> policyQuestions = new ArrayList<PolicyQuestions>();
		PolicyQuestions polQues = null;
		try {
			connection = JdbcUtility.getConnection();
			System.out.println(busSegId);
			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_POLICY_QUESTIONS);
			prepareStatement.setString(1, busSegId);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				polQues = new PolicyQuestions();
				polQues.setPolQuesId(resultSet.getString(1));
				polQues.setPolQuesSeq(resultSet.getInt(2));
				polQues.setBusSegId(resultSet.getString(3));
				polQues.setPolQuesDesc(resultSet.getString(4));
				polQues.setPolQuesAns1(resultSet.getString(5));
				polQues.setPolQuesAns1Weightage(resultSet.getInt(6));
				polQues.setPolQuesAns2(resultSet.getString(7));
				polQues.setPolQuesAns2Weightage(resultSet.getInt(8));
				polQues.setPolQuesAns3(resultSet.getString(9));
				polQues.setPolQuesAns3Weightage(resultSet.getInt(10));
				policyQuestions.add(polQues);
			}
			logger.info("Getting policy questions for business segment id "+busSegId);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println(policyQuestions);
		return policyQuestions;
	}
	
	//Method for getting the policy premium amount 
	@Override
	public int getPolicyPremiumAmount(int sumOfWeightages) throws QGSException {
		// TODO Auto-generated method stub
		int preAmt = 0;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();
			System.out.println(sumOfWeightages);
			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_POLICY_PREMIUM_AMOUNT);
			prepareStatement.setDouble(1, sumOfWeightages);
			resultSet = prepareStatement.executeQuery();
			System.out.println(sumOfWeightages);
			found = resultSet.next();
			if(found == true) {
				preAmt = resultSet.getInt(1);
				logger.info("The policy Premium amount for the user based on selected answers is: "+preAmt);
			}
			
			if(resultSet.next()) {
				preAmt = resultSet.getInt(4);
			}
			
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}

		return preAmt;

	}
	
	//Method for adding policy 
	@Override
	public int createPolicy(Policy policy) throws QGSException {
		// TODO Auto-generated method stub
		int isInserted = 0;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.CREATE_POLICY);
			prepareStatement.setDouble(1, policy.getPolicyPremium());
			prepareStatement.setInt(2, policy.getAccNumber());
			
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting details into the policy table after calculating premium amount for the account: "+policy.getAccNumber());
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
		return isInserted;

	}
	
	//Method for getting the policy number to add policy details 
	@Override
	public int getPolicyNumber() throws QGSException {
		// TODO Auto-generated method stub
		int polNumber = 0;
		boolean found = false;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_POLICY_NUMBER);	
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			System.out.println(found);
			if(found == true) {
				polNumber = resultSet.getInt(1);

			}
					
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
		return polNumber;

	}
	
	//Method for adding policy details
	@Override
	public void addPolicyDetails(int polNumber, List<String> questionIds, List<String> selectedAnswers)
			throws QGSException {
	
		// TODO Auto-generated method stub
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.ADD_POLICY_DETAILS);	
			for(int i = 0; i < questionIds.size(); i++) {
				prepareStatement.setInt(1, polNumber);
				prepareStatement.setString(2, questionIds.get(i));
				prepareStatement.setString(3, selectedAnswers.get(i));
				prepareStatement.executeUpdate();
			}		
			logger.info("Inserting the selected question id's and answers into the policydetails table");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}

	}
	
	//Method for adding policy creator name and policy number
	@Override
	public void addPolicyCreator(int polNumber, String username) throws QGSException {
		// TODO Auto-generated method stub
		int isInserted = 0;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.ADD_POLICY_CREATOR);
			prepareStatement.setInt(1, polNumber);
			prepareStatement.setString(2,username);
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting policy number and user name into policyCreator table for the policies created by the agents");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
	}
	
	//Method for getting list of policies created by agent
	@Override
	public List<Policy> getPolicies(String username) throws QGSException {
		
		List<Policy> policies = new ArrayList<Policy>();
		Policy policy;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.VIEW_POLICY);
			prepareStatement.setString(1,username);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				policy = new Policy();
				policy.setPolicyNumber(resultSet.getInt(1));
				policy.setPolicyPremium(resultSet.getDouble(2));
				policy.setAccNumber(resultSet.getInt(3));
				policies.add(policy);
			}
			logger.info("Getting all the list of policies created ");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}		
		return policies;
	}
	
	//Method for getting the account details of user to generate report
	@Override
	public Accounts getAccountDetails(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		Accounts account = new Accounts();
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_ACCOUNT_DETAILS);	
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();

			if(resultSet.next()) {
				account.setAccountNumber(resultSet.getInt(1));
				account.setInsuredName(resultSet.getString(2));
				account.setInsuredStreet(resultSet.getString(3));
				account.setInsuredCity(resultSet.getString(4));
				account.setInsuredState(resultSet.getString(5));
				account.setInsuredZip(resultSet.getInt(6));
				account.setLineOfBusiness(resultSet.getString(7));
				
			}
			logger.info("Getting the account details for account number "+accNumber+" "+"to generate a detailed report");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}		
		
		return account;
	}

	//Method for getting business segment name
	@Override
	public String getBusSegName(String lineOfBusiness) throws QGSException {
		// TODO Auto-generated method stub
		String busSegName = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_BUS_SEG_NAME);
			prepareStatement.setString(1, lineOfBusiness);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return busSegName;

	}
	
	//Method to get policy premium amount for generating a report
	@Override
	public Double getPolicyPremium(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		Double polPremium = 0.0;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_POLICY_PREMIUM);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				polPremium = resultSet.getDouble(1);
				logger.info("Getting policy premium amount for generating a detailed report for policy number" + polNum);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println("policy premium in dao is : " + polPremium);
		return polPremium;

	}

	//Method to get selected answers for generating detailed report
	@Override
	public List<String> getSelectedAnswers(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		List<String> selectedAns = new ArrayList<String>();
		PolicyDetails details = null;
		boolean isFound = false;
		connection = JdbcUtility.getConnection();
		try {
			
			prepareStatement = connection.prepareStatement(AgentQueryConstants.GET_SELECTED_ANSWERS);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				selectedAns.add(resultSet.getString(1));
			}
			logger.info("Getting the selected answers for generating detailed report for policy number: "+polNum);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object "+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println("Inside dao answers are:"+selectedAns);
		return selectedAns;

	}

	
	
	
}
