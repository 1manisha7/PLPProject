package com.cg.qgs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.qgs.controller.ProfileCreation;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyDetails;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.utility.JdbcUtility;

public class InsuredDAO implements IInsuredDAO{
	
	final Logger logger = Logger.getLogger(ProfileCreation.class);
	Connection connection = null;
	PreparedStatement prepareStatement = null;
	ResultSet resultSet=null;
	
	
	//Method to validate whether the account exists for the user or not
	@Override
	public boolean accountValidation(String username) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(InsuredQueryConstants.VALIDATE_ACCOUNT_QUERY);
			prepareStatement.setString(1, username);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}

	
	//Method to get business id based on business segment name entered by the user
	@Override
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QGSException {
		// TODO Auto-generated method stub
		String businessSegmentId = null;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_LOB_NAME);
			prepareStatement.setString(1, lineOfBusinessName);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				businessSegmentId = resultSet.getString(1);
				logger.info("Business segment id based on business segment name is: "+businessSegmentId);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return businessSegmentId;
	}
	
	//Method to create account for the insured
	@Override
	public int accountCreation(Accounts account,String userName) throws QGSException {
		// TODO Auto-generated method stub

		connection = JdbcUtility.getConnection();
		int isInserted = 0;
		try {
			prepareStatement = connection.prepareStatement(InsuredQueryConstants.ACCOUNT_CREATION);
			prepareStatement.setString(1, account.getInsuredName());
			prepareStatement.setString(2, account.getInsuredStreet());
			prepareStatement.setString(3, account.getInsuredCity());
			prepareStatement.setString(4, account.getInsuredState());
			prepareStatement.setInt(5, account.getInsuredZip());
			prepareStatement.setString(6, account.getLineOfBusiness());
			prepareStatement.setString(7, userName);
			
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting account details of the user into the accounts table with username: "+userName);

		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				prepareStatement.close();
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return isInserted;
	}
	
	//Method to find account number for the user to view his policy
	@Override
	public int getAccountNumber(String username) throws QGSException {
		// TODO Auto-generated method stub
		int accNo = 0;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_ACCOUNT_NUMBER);
			prepareStatement.setString(1, username);
			
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				
				accNo = resultSet.getInt(1);
				logger.info("Getting the account number of the insured with username: "+username);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return accNo;

	}
	
	//Method to get list of policies for that particular insured
	@Override
	public List<Policy> getInsuredPolicies(int accNo) throws QGSException {
		// TODO Auto-generated method stub
		List<Policy> policies = new ArrayList<Policy>();
		Policy policy;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_INSURED_POLICY);	
			prepareStatement.setInt(1, accNo);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				policy = new Policy();
				policy.setPolicyNumber(resultSet.getInt(1));
				policy.setPolicyPremium(resultSet.getDouble(2));
				policy.setAccNumber(resultSet.getInt(3));
				policies.add(policy);
			}
			logger.info("Getting list of policies of the insured with account number: "+accNo);
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}		
		return policies;
}

	//Method to find business segment name based on business segment id
	@Override
	public String getBusSegName(String busSegId) throws QGSException {
		// TODO Auto-generated method stub
		String busSegName = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_BUS_SEG_NAME);
			prepareStatement.setString(1, busSegId);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return busSegName;
	}

	//Getting account details of Insured for generating report
	@Override
	public Accounts getAccountDetails(Integer accNumber) throws QGSException {
		// TODO Auto-generated method stub
		Accounts account = new Accounts();
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_ACCOUNT_DETAILS);	
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();

			if(resultSet.next()) {
				account.setAccountNumber(resultSet.getInt(1));
				account.setInsuredName(resultSet.getString(2));
				account.setInsuredStreet(resultSet.getString(3));
				account.setInsuredCity(resultSet.getString(4));
				account.setInsuredState(resultSet.getString(5));
				account.setInsuredZip(resultSet.getInt(6));
				account.setLineOfBusiness(resultSet.getString(7));
			}
			logger.info("Getting the account details of the insured with account number: "+accNumber);
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while closing");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
				
			}
		}		
		
		return account;
	}

    //Method for getting the policy premium amount of the insured
	@Override
	public Double getPolicyPremium(Integer polNum) throws QGSException {
		// TODO Auto-generated method stub
		Double polPremium = 0.0;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_POLICY_PREMIUM);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				polPremium = resultSet.getDouble(1);
				logger.info("The policy Premium amount for the user based on selected answers is: "+polPremium);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return polPremium;
	}

	//Method for getting policy questions of related business segment id
	@Override
	public List<PolicyQuestions> getPolicyQuestions(String lineOfBusinessId) throws QGSException {
		// TODO Auto-generated method stub
		List<PolicyQuestions> policyQuestions = new ArrayList<PolicyQuestions>();
		PolicyQuestions polQues = null;
		try {
			connection = JdbcUtility.getConnection();
			System.out.println(lineOfBusinessId);
			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_POLICY_QUESTIONS);
			prepareStatement.setString(1, lineOfBusinessId);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				polQues = new PolicyQuestions();
				polQues.setPolQuesId(resultSet.getString(1));
				polQues.setPolQuesSeq(resultSet.getInt(2));
				polQues.setBusSegId(resultSet.getString(3));
				polQues.setPolQuesDesc(resultSet.getString(4));
				polQues.setPolQuesAns1(resultSet.getString(5));
				polQues.setPolQuesAns1Weightage(resultSet.getInt(6));
				polQues.setPolQuesAns2(resultSet.getString(7));
				polQues.setPolQuesAns2Weightage(resultSet.getInt(8));
				polQues.setPolQuesAns3(resultSet.getString(9));
				polQues.setPolQuesAns3Weightage(resultSet.getInt(10));
				policyQuestions.add(polQues);
			}
			logger.info("Getting the policy questions for the business segment id: "+lineOfBusinessId);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return policyQuestions;

	}
	
	//Method for getting the answers selected by Insured
	@Override
	public  List<String> getSelectedAnswers(Integer polNum) throws QGSException {
		// TODO Auto-generated method stub
		List<String> selectedAns = new ArrayList<String>();
		PolicyDetails details = null;
		boolean isFound = false;
		connection = JdbcUtility.getConnection();
		try {
			
			prepareStatement = connection.prepareStatement(InsuredQueryConstants.GET_SELECTED_ANSWERS);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				selectedAns.add(resultSet.getString(1));
			}
			logger.info("Getting the sleceted answers of the Insured for the policy number: "+polNum); 
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object "+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println("Inside dao answers are:"+selectedAns);
		return selectedAns;
	}


	


	
	

	
	
	
	
	
}


