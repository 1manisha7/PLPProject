package com.cg.qgs.dao;

public interface AdminQueryConstants {
	
	//Login validation
	
	String VALIDATE_USER_QUERY = "SELECT * FROM userrole WHERE username = ? and password = ?";
	
	String GET_ROLECODE = "SELECT rolecode FROM userrole WHERE username = ? and password = ?";
	
	String ADD_USER = "INSERT INTO userRole VALUES(?,?,?)";
	
	//Account Creation
	
	String GET_LOB_NAME = "SELECT bus_seg_id FROM businesssegment WHERE bus_seg_name = ?";
	
	String USER_EXISTS = "SELECT * FROM userrole WHERE username = ?";
	
	String ACCOUNT_CREATION = "INSERT INTO accounts VALUES(account_number.nextval,?,?,?,?,?,?,?)";
	
	//Policy Creation
	
	String GET_BUS_SEG_ID = "SELECT businesssegmentid FROM accounts WHERE accountnumber = ?";
	
	String GET_POLICY_QUESTIONS = "SELECT * FROM policyquestions WHERE bus_seg_id = ?";
	
	String GET_POLICY_PREMIUM_AMOUNT = "SELECT pre_amt FROM premiums WHERE ? BETWEEN pre_ans_weightage_min and pre_ans_weightage_max";
	
	String CREATE_POLICY = "INSERT INTO policy VALUES(policy_number.nextval, ?, ?)";
	
    String GET_POLICY_NUMBER = "SELECT MAX(policynumber) FROM policy";
    
    String ADD_POLICY_DETAILS = "INSERT INTO policydetails VALUES(?,?,?)";
	
	//view policy
	
	String GET_POLICIES = "SELECT * FROM policy";
	
	//Generating report
	
	String GET_ACCOUNT_DETAILS = "SELECT * FROM accounts WHERE accountnumber = ?";
	
	String GET_BUS_SEG_NAME = "SELECT bus_seg_name FROM businesssegment WHERE bus_seg_id = ?";
	
	String GET_POLICY_PREMIUM = "SELECT policypremium FROM policy WHERE policynumber = ?";
	
	String GET_SELECTED_ANSWERS = "SELECT answer FROM policydetails WHERE policynumber = ?";
	
	
}
