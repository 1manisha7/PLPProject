package com.cg.qgs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import com.cg.qgs.controller.ProfileCreation;
import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyDetails;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.model.UserRole;
import com.cg.qgs.utility.JdbcUtility;

public class AdminDAO implements IAdminDAO{

	final Logger logger = Logger.getLogger(ProfileCreation.class);
	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;
	
	//Method for validating whether the user exists in userole table or not
	public boolean loginValidation(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.VALIDATE_USER_QUERY);
			prepareStatement.setString(1, username);
			prepareStatement.setString(2, password);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
				String name = resultSet.getString(1);
				String pwd = resultSet.getString(2);
			}
			else {
				logger.info("User does not exist!!");
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}
	

	@Override
	public String getRoleCode(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		String roleCode = "";
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_ROLECODE);
			prepareStatement.setString(1, username);
			prepareStatement.setString(2, password);
		
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				roleCode = resultSet.getString(1);
			}
			logger.info("The rolecode of logged user is: "+roleCode);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return roleCode;
	}
	
	
	
	//Method for adding new user into userrole table
	@Override
	public int addUser(UserRole userRole) throws QGSException {
		// TODO Auto-generated method stub
		int isInserted = 0;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.ADD_USER);
			prepareStatement.setString(1, userRole.getUserName());
			prepareStatement.setString(2, userRole.getPassword());
			prepareStatement.setString(3, userRole.getRoleCode());
			isInserted = prepareStatement.executeUpdate();
			logger.info("Creating Profile for new user with username :"+userRole.getUserName()+","+"password: "+userRole.getPassword()+","+"Rolecode: "+userRole.getRoleCode());
		}
		catch(SQLException e)
		{	
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
		return isInserted;
	}
	
	//Method for getting lineofbusinessId by BusinessSegment name
	@Override
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QGSException {
		// TODO Auto-generated method stub
		String businessSegmentId = null;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_LOB_NAME);
			prepareStatement.setString(1, lineOfBusinessName);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				businessSegmentId = resultSet.getString(1);
	             logger.info("Business segment id based on business segment name is: "+businessSegmentId);
				
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return businessSegmentId;
	}
	
	//Method to check whether user exists or not for creating account
	@Override
	public boolean isUserExists(String userName) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.USER_EXISTS);
			prepareStatement.setString(1, userName);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
				logger.info("User exists so account can be created for the user with username: "+userName);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}
	
	//Method to create an account if the user exists
	@Override
	public int accountCreation(Accounts account,String userName) throws QGSException {
		// TODO Auto-generated method stub

		connection = JdbcUtility.getConnection();
		int isInserted = 0;
		try {
			prepareStatement = connection.prepareStatement(AdminQueryConstants.ACCOUNT_CREATION);
			prepareStatement.setString(1, account.getInsuredName());
			prepareStatement.setString(2, account.getInsuredStreet());
			prepareStatement.setString(3, account.getInsuredCity());
			prepareStatement.setString(4, account.getInsuredState());
			prepareStatement.setInt(5, account.getInsuredZip());
			prepareStatement.setString(6, account.getLineOfBusiness());
			prepareStatement.setString(7, userName);
			
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting account details of the user into the accounts table with username: "+userName);

		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				prepareStatement.close();
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return isInserted;
	}
	
	//Method to get business segment id of the user based on account number entered
	@Override
	public String getBusSegId(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		String busSegId = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_BUS_SEG_ID);
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegId = resultSet.getString(1);
				logger.info("Getting the business segment id from accounts table for account number "+accNumber +" " +" for creating a new policy");
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return busSegId;
	}

	//Method to get policy questions for the related business segment Id
	@Override
	public List<PolicyQuestions> getPolicyQuestions(String busSegId) throws QGSException {
		List<PolicyQuestions> policyQuestions = new ArrayList<PolicyQuestions>();
		PolicyQuestions polQues = null;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_POLICY_QUESTIONS);
			prepareStatement.setString(1, busSegId);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				polQues = new PolicyQuestions();
				polQues.setPolQuesId(resultSet.getString(1));
				polQues.setPolQuesSeq(resultSet.getInt(2));
				polQues.setBusSegId(resultSet.getString(3));
				polQues.setPolQuesDesc(resultSet.getString(4));
				polQues.setPolQuesAns1(resultSet.getString(5));
				polQues.setPolQuesAns1Weightage(resultSet.getInt(6));
				polQues.setPolQuesAns2(resultSet.getString(7));
				polQues.setPolQuesAns2Weightage(resultSet.getInt(8));
				polQues.setPolQuesAns3(resultSet.getString(9));
				polQues.setPolQuesAns3Weightage(resultSet.getInt(10));
				policyQuestions.add(polQues);
			}
			logger.info("Getting policy questions for business segment id "+busSegId);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println(policyQuestions);
		return policyQuestions;
	}
	
	//Method to get policy premium amount based on the answers selected by user
	@Override
	public Integer getPolicyPremiumAmount(Integer sumOfWeightages) throws QGSException {
		int preAmt = 0;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_POLICY_PREMIUM_AMOUNT);
			prepareStatement.setDouble(1, sumOfWeightages);
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			System.out.println(found);
			if(found == true) {
				preAmt = resultSet.getInt(1);
				logger.info("The policy Premium amount for the user based on selected answers is: "+preAmt);
			}
			
			if(resultSet.next()) {
				preAmt = resultSet.getInt(4);
			}
			
			
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}

		return preAmt;
	}
	
	//Method for creating policy
	@Override
	public Integer createPolicy(Policy policy) throws QGSException {
		int isInserted = 0;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.CREATE_POLICY);
			prepareStatement.setDouble(1, policy.getPolicyPremium());
			prepareStatement.setInt(2, policy.getAccNumber());
			isInserted = prepareStatement.executeUpdate();
			logger.info("Inserting details into the policy table after calculating premium amount for the account: "+policy.getAccNumber());
		}
		catch(SQLException e)
		{	
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");			
			}
		}
		return isInserted;
	}
	
	//Method to get policy number from policy table to insert policy details into ploicydetails table
	@Override
	public Integer getPolicyNumber() throws QGSException {
		// TODO Auto-generated method stub
		int polNumber = 0;
		boolean found = false;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_POLICY_NUMBER);	
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				polNumber = resultSet.getInt(1);

			}
			
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
		return polNumber;
	}
	
	//Method to add policyDetails
	@Override
	public void addPolicyDetails(int polNumber, List<String> questionIds, List<String> selectedAnswers)
			throws QGSException {
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.ADD_POLICY_DETAILS);	
			for(int i = 0; i < questionIds.size(); i++) {
				prepareStatement.setInt(1, polNumber);
				prepareStatement.setString(2, questionIds.get(i));
				prepareStatement.setString(3, selectedAnswers.get(i));
				prepareStatement.executeUpdate();
				
			}	
			logger.info("Inserting the selected question id's and answers into the policydetails table");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}
		
	}
    
	//Method to get all the list of policies
	@Override
	public List<Policy> getPolicies() throws QGSException {
		// TODO Auto-generated method stub
		List<Policy> policies = new ArrayList<Policy>();
		Policy policy;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_POLICIES);	
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				policy = new Policy();
				policy.setPolicyNumber(resultSet.getInt(1));
				policy.setPolicyPremium(resultSet.getDouble(2));
				policy.setAccNumber(resultSet.getInt(3));
				policies.add(policy);
			}
			logger.info("Getting all the list of policies created ");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}		
		return policies;
	}

	//Method for getting account details for generating report
	@Override
	public Accounts getAccountDetails(Integer accNumber) throws QGSException {
		// TODO Auto-generated method stub
		Accounts account = new Accounts();
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_ACCOUNT_DETAILS);	
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();

			if(resultSet.next()) {
				account.setAccountNumber(resultSet.getInt(1));
				account.setInsuredName(resultSet.getString(2));
				account.setInsuredStreet(resultSet.getString(3));
				account.setInsuredCity(resultSet.getString(4));
				account.setInsuredState(resultSet.getString(5));
				account.setInsuredZip(resultSet.getInt(6));
				account.setLineOfBusiness(resultSet.getString(7));
				
			}
			logger.info("Getting the account details for account number "+accNumber+" "+"to generate a detailed report");
		}
		catch(SQLException e)
		{
			throw new QGSException("problem while creating PS object");
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				throw new QGSException("problem while closing");
			}
		}		
		
		return account;
	}
	
	//Method for getting business segment name 
	@Override
	public String getBusSegName(String busSegId) throws QGSException {
		
		String busSegName = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_BUS_SEG_NAME);
			prepareStatement.setString(1, busSegId);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegName = resultSet.getString(1);

			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return busSegName;
	}
	
	//Method for getting policy premium for generating report
	@Override
	public Double getPolicyPremium(Integer polNum) throws QGSException {
		
		Double polPremium = 0.0;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_POLICY_PREMIUM);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				polPremium = resultSet.getDouble(1);
				logger.info("Getting policy premium amount for generating a detailed report for policy number" + polNum);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println("policy premium in dao is : " + polPremium);
		return polPremium;
	}
	
	//Method for getting selected answers for generating report
	@Override
	public  List<String> getSelectedAnswers(int polNum) throws QGSException {
		// TODO Auto-generated method stub
		List<String> selectedAns = new ArrayList<String>();
		PolicyDetails details = null;
		boolean isFound = false;
		connection = JdbcUtility.getConnection();
		try {
			
			prepareStatement = connection.prepareStatement(AdminQueryConstants.GET_SELECTED_ANSWERS);
			prepareStatement.setInt(1, polNum);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				selectedAns.add(resultSet.getString(1));
			}
			logger.info("Getting the selected answers for generating detailed report for policy number: "+polNum);
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object "+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return selectedAns;
	}
	
}
