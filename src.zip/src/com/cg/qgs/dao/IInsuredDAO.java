package com.cg.qgs.dao;

import java.util.List;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyQuestions;

public interface IInsuredDAO {

	public boolean accountValidation(String username) throws QGSException;
	
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QGSException;
	
	public int accountCreation(Accounts account, String userName) throws QGSException;
	
	public List<Policy> getInsuredPolicies(int accNo) throws QGSException;
	
	public int getAccountNumber(String username) throws QGSException;
	
	public Accounts getAccountDetails(Integer accNo) throws QGSException;
	
	public String getBusSegName(String lineOfBusiness) throws QGSException;
	
	public Double getPolicyPremium(Integer polNum) throws QGSException;
	
	public List<PolicyQuestions> getPolicyQuestions(String lineOfBusiness) throws QGSException;
	
	public List<String> getSelectedAnswers(Integer polNum) throws QGSException;


}
