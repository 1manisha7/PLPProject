package com.cg.qgs.exceptions;

public class QGSException extends Exception {
	public QGSException(String message){
		super(message);
	}
}
